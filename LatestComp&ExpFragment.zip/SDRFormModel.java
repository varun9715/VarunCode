package ai.marcel.contentadmin.core.models;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceNotFoundException;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
  
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SDRFormModel {
	private static final Logger LOG = LoggerFactory.getLogger(SDRFormModel.class);

	@Inject
	@ChildResource
    private Resource formFields;
	
	@ValueMapValue
	@Default(values = StringUtils.EMPTY)
    private String mainTitle;
	
	@ValueMapValue
	@Default(values = StringUtils.EMPTY)
    private String secondaryTitle;
	
	private List<SDRFormListModel> sdrFormList;
	
	@PostConstruct
	protected void init() {
		sdrFormList = new ArrayList<>();
		try {
			if(formFields.hasChildren()) {
				Iterator<Resource> childItems = formFields.listChildren();
				while(childItems.hasNext()) {
					SDRFormListModel resourceprop = childItems.next().adaptTo(SDRFormListModel.class);
					sdrFormList.add(resourceprop);
					System.out.println();
				}
			}
		} catch(ResourceNotFoundException e) {
			LOG.error("SDR Form component: Resource not found. {}",e.getMessage());
		} catch(Exception ex) {
			LOG.error("Exception:",ex.getMessage());
		}
	}

	public List<SDRFormListModel> getSdrFormList() {
		return sdrFormList;
	}

	public void setSdrFormList(List<SDRFormListModel> sdrFormList) {
		this.sdrFormList = sdrFormList;
	}

	public String getMainTitle() {
		return mainTitle;
	}

	public void setMainTitle(String mainTitle) {
		this.mainTitle = mainTitle;
	}

	public String getSecondaryTitle() {
		return secondaryTitle;
	}

	public void setSecondaryTitle(String secondaryTitle) {
		this.secondaryTitle = secondaryTitle;
	}
}